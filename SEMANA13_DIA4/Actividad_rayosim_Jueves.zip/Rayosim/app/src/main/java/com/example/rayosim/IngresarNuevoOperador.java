package com.example.rayosim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IngresarNuevoOperador extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ingresar_nuevo_operador);
    }
}