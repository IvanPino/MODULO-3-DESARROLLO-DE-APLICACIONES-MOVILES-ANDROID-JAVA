package com.example.rayosim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IngresarPaciente extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ingr_paciente);
    }
}